const NowPlaying = ()=>{
    return(
        <></>
    )
}

export default NowPlaying;
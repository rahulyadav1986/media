const TopRated = ()=>{
    return(
        <></>
    )
}

export default TopRated;
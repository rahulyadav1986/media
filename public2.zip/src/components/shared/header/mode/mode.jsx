import styles from './style.module.scss';

const Mode = ()=>{
    return(
        <>
            <div className={styles.mode}></div>
        </>
    )
}

export default Mode;
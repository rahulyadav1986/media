const Footer = ()=>{
    return(
        <>
             <h1>Footer</h1>
        </>
    )
}

export default Footer;